import { RegisterUser } from "../../application/use-cases/register-user.use-case.js";
import { SendEmailVerificationOtp } from "../../application/use-cases/send-email-verification-otp.use-case.js";

import { PostgresUserRepository } from "../database/postgres/repositories/postgres-user.repository.js";
import { PostgresVerificationChallengeRepository } from "../database/postgres/repositories/postgres-verification-challenge.repository.js";

import { postgresPool } from "../database/postgres/pool.js";

import { BcryptPasswordHasher } from "../security/bcrypt-password-hasher.js";
import { NodemailerEmailSender } from "../email/nodemailer-email-sender.js";
import { CryptoOtpGenerator } from "../security/crypto-otp-generator.js";
import { HmacOtpHasher } from "../security/hmac-otp-hasher.js";
import { VerifyEmailOtp } from "../../application/use-cases/verify-email-otp.use-case.js";
import { VerifyEmailOtpController } from "../../presentation/http/controllers/verify-email-otp.controller.js";

import { CryptoRefreshTokenGenerator } from "../security/crypto-refresh-token-generator.js";
import { JwtAccessTokenGenerator } from "../security/jwt-access-token-generator.js";
import { PostgresRefreshSessionRepository } from "../database/postgres/repositories/postgres-refresh-session.repository.js";

import { LoginUser } from "../../application/use-cases/login-user.use-case.js";

import { RefreshAccessToken } from "../../application/use-cases/refresh-access-token.use-case.js";
import { LogoutUser } from "../../application/use-cases/logout-user.use-case.js";
import { JwtAccessTokenVerifier } from "../security/jwt-access-token-verifier.js";
import { AuthenticateMiddleware } from "../../presentation/http/middlewares/authenticate.middleware.js";
import { GetCurrentUserController } from "../../presentation/http/controllers/get-current-user.controller.js";

import { AuthorizeRolesMiddleware } from "../../presentation/http/middlewares/authorize-roles.middleware.js";
import { ResendEmailVerificationOtpController } from "../../presentation/http/controllers/resend-email-verification-otp.controller.js";


const userRepository = new PostgresUserRepository(postgresPool);

const verificationChallengeRepository =
  new PostgresVerificationChallengeRepository(postgresPool);

const passwordHasher = new BcryptPasswordHasher();

export const emailSender = new NodemailerEmailSender();

export const otpGenerator = new CryptoOtpGenerator();
export const otpHasher = new HmacOtpHasher();

export { verificationChallengeRepository };

export const sendEmailVerificationOtp = new SendEmailVerificationOtp(
  userRepository,
  verificationChallengeRepository,
  otpGenerator,
  otpHasher,
  emailSender,
);

export const registerUser = new RegisterUser(
  userRepository,
  passwordHasher,
  sendEmailVerificationOtp,
);

export const verifyEmailOtp = new VerifyEmailOtp(
  userRepository,
  verificationChallengeRepository,
  otpHasher,
);

export const verifyEmailOtpController = new VerifyEmailOtpController(
  verifyEmailOtp,
);

export const resendEmailVerificationOtpController =
  new ResendEmailVerificationOtpController(
    userRepository,
    sendEmailVerificationOtp,
  );

const refreshSessionRepository = new PostgresRefreshSessionRepository(postgresPool);
export const refreshTokenGenerator = new CryptoRefreshTokenGenerator();
export const accessTokenGenerator = new JwtAccessTokenGenerator();
export const accessTokenVerifier = new JwtAccessTokenVerifier();


export const authenticateMiddleware = new AuthenticateMiddleware(
  accessTokenVerifier,
);

export const authorizeRolesMiddleware = new AuthorizeRolesMiddleware(userRepository);


export const getCurrentUserController = new GetCurrentUserController(
  userRepository,
);


export const loginUser = new LoginUser(
  userRepository,
  passwordHasher,
  accessTokenGenerator,
  refreshTokenGenerator,
  refreshSessionRepository,
);

export const refreshAccessToken = new RefreshAccessToken(
  userRepository,
  refreshSessionRepository,
  accessTokenGenerator,
  refreshTokenGenerator,
);

export const logoutUser = new LogoutUser(
  refreshSessionRepository,
  refreshTokenGenerator,
);